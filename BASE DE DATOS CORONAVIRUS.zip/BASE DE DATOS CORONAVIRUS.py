from tkinter import *
from tkinter.ttk import *
import mysql.connector

mydb=mysql.connector.connect(
    host="127.0.0.1",
    user="root",
    password="",
    database="Coronavirus"
)
mycursor= mydb.cursor()

ventana=Tk()
ventana.title("MENU PRINCIPAL")
ventana.geometry("450x400")
imagen= PhotoImage(file="Corona.png")
fondo =Label(ventana,image=imagen).place(x=0,y=0)

def baja_california():

    mycursor.execute("SELECT * FROM covid where Numero='1'")
    myresult= mycursor.fetchall()

    a=myresult[0][0]
    b=myresult[0][1]
    c=myresult[0][2]
    d=myresult[0][3]

    print("")
    ventana.destroy()
    ventana.__init__()
    ventana.geometry("550x250")
    ventana.title("BAJA CALIFORNIA")
    imagen= PhotoImage(file="Corona.png")
    fondo =Label(ventana,image=imagen).place(x=0,y=0)
        
    eti=Label(ventana, text="Numero     Casos Confirmados       Recuperados     Fallecidos")
    eti.place(x=93,y=50)
    et=Label(ventana, text=a)
    et.place(x=115, y=70)
    et=Label(ventana, text=b)
    et.place(x=190, y=70)
    et=Label(ventana, text=c)
    et.place(x=291, y=70)
    et=Label(ventana, text=d)
    et.place(x=373, y=70)

    boton=Button(ventana,text="Salir",command=salir)
    boton.place(x=210,y=140)

def coahuila():

    mycursor.execute("SELECT * FROM covid where Numero='2'")
    myresult= mycursor.fetchall()

    a=myresult[0][0]
    b=myresult[0][1]
    c=myresult[0][2]
    d=myresult[0][3]

    print("")
    ventana.destroy()
    ventana.__init__()
    ventana.geometry('550x250')
    ventana.title("COAHUILA")
    imagen= PhotoImage(file="Corona.png")
    fondo =Label(ventana,image=imagen).place(x=0,y=0)
        
    eti=Label(ventana, text="Numero     Casos Confirmados       Recuperados     Fallecidos")
    eti.place(x=93,y=50)
    et=Label(ventana, text=a)
    et.place(x=115, y=70)
    et=Label(ventana, text=b)
    et.place(x=190, y=70)
    et=Label(ventana, text=c)
    et.place(x=291, y=70)
    et=Label(ventana, text=d)
    et.place(x=373, y=70)
    
    boton=Button(ventana,text="Salir",command=salir)
    boton.place(x=210,y=140)

def durango():
    mycursor.execute("SELECT * FROM covid where Numero='3'")
    myresult= mycursor.fetchall()

    a=myresult[0][0]
    b=myresult[0][1]
    c=myresult[0][2]
    d=myresult[0][3]

    print("")
    ventana.destroy()
    ventana.__init__()
    ventana.geometry("550x250")
    ventana.title("DURANGO")
    imagen= PhotoImage(file="Corona.png")
    fondo =Label(ventana,image=imagen).place(x=0,y=0)
        
    eti=Label(ventana, text="Numero     Casos Confirmados       Recuperados     Fallecidos")
    eti.place(x=93,y=50)
    et=Label(ventana, text=a)
    et.place(x=115, y=70)
    et=Label(ventana, text=b)
    et.place(x=190, y=70)
    et=Label(ventana, text=c)
    et.place(x=291, y=70)
    et=Label(ventana, text=d)
    et.place(x=373, y=70)
    
    boton=Button(ventana,text="Salir",command=salir)
    boton.place(x=210,y=140)

def guerrero():
    mycursor.execute("SELECT * FROM covid where Numero='4'")
    myresult= mycursor.fetchall()

    a=myresult[0][0]
    b=myresult[0][1]
    c=myresult[0][2]
    d=myresult[0][3]

    print("")
    ventana.destroy()
    ventana.__init__()
    ventana.geometry("550x250")
    ventana.title("GUERRERO")
    imagen= PhotoImage(file="Corona.png")
    fondo =Label(ventana,image=imagen).place(x=0,y=0)
        
    eti=Label(ventana, text="Numero     Casos Confirmados       Recuperados     Fallecidos")
    eti.place(x=93,y=50)
    et=Label(ventana, text=a)
    et.place(x=115, y=70)
    et=Label(ventana, text=b)
    et.place(x=190, y=70)
    et=Label(ventana, text=c)
    et.place(x=291, y=70)
    et=Label(ventana, text=d)
    et.place(x=373, y=70)
    
    boton=Button(ventana,text="Salir",command=salir)
    boton.place(x=210,y=140)


def jalisco():
    mycursor.execute("SELECT * FROM covid where Numero='5'")
    myresult= mycursor.fetchall()

    a=myresult[0][0]
    b=myresult[0][1]
    c=myresult[0][2]
    d=myresult[0][3]

    print("")
    ventana.destroy()
    ventana.__init__()
    ventana.geometry("550x250")
    ventana.title("JALISCO")
    imagen= PhotoImage(file="Corona.png")
    fondo =Label(ventana,image=imagen).place(x=0,y=0)
        
    eti=Label(ventana, text="Numero     Casos Confirmados       Recuperados     Fallecidos")
    eti.place(x=93,y=50)
    et=Label(ventana, text=a)
    et.place(x=115, y=70)
    et=Label(ventana, text=b)
    et.place(x=190, y=70)
    et=Label(ventana, text=c)
    et.place(x=291, y=70)
    et=Label(ventana, text=d)
    et.place(x=373, y=70)
    
    boton=Button(ventana,text="Salir",command=salir)
    boton.place(x=210,y=140)
 
def salir():
    ventana.destroy()

def agg():
     ventana.destroy()
     ventana.__init__()
     def guardar():
          mycursor.execute("SELECT MAX (Numero) AS maximum FROM NumeroE")
          result = mycursor.fetchall()
          for i in result:
               x=i[0]
          x=x+1
          sql=("""INSERT INTO covid2 (Numero,NumeroE) VALUES (%s,%s)""")
          val= (x,covid2.get())
          sqll = ("""INSERT INTO covid (Numero, Casos Confirmados, Recuperados, Fallecidos) VALUES (%s,%s,%s,%s) """)
          vall = (x,Casos_Confirmados.get(),Recuperados.get(),Fallecidos.get())
          mycursor.execute(sql, val)
          mycursor.execute(sqll, vall)
          mydb.commit()
          ventana.destroy()
          ventana.__init__()
          ventana.title("Añadir")
          ventana.geometry("525x250")
          eti=Label(ventana, text="Se guardo correctamente")
          eti.place(x=220,y=20)
          boton=Button(ventana,text="Salir",command=salir)
          boton.place(x=250,y=180)
          
     ventana.title("Añadir")
     ventana.geometry("525x250")

     etiqueta=Label(ventana,text="Nombre:")
     etiqueta.place(x=30,y=20)
     etiqueta=Label(ventana,text="Casos Confirmados:")
     etiqueta.place(x=25,y=50)
     etiqueta=Label(ventana,text="Reuperados:")
     etiqueta.place(x=30,y=80)
     etiqueta=Label(ventana,text="Fallecidos:")
     etiqueta.place(x=30,y=110)

     Nombre=StringVar()
     cajatexto=Entry(ventana,textvariable=Nombre)
     cajatexto.place(x=105,y=20)
     Casos_Confirmados=IntVar()
     cajatexto=Entry(ventana,textvariable=Casos_Confirmados)
     cajatexto.place(x=135,y=50)
     Recuperados=IntVar()
     cajatexto=Entry(ventana,textvariable=Recuperados)
     cajatexto.place(x=105,y=80)
     Fallecidos=IntVar()
     cajatexto=Entry(ventana,textvariable=Fallecidos)
     cajatexto.place(x=105,y=110)
     
     boton=Button(ventana,text='Guardar',command=guardar)
     boton.place(x=235,y=180)


    
b1=Button(ventana,text="BAJA CALIFORNIA",command=baja_california).place(x=165,y=50)
b2=Button(ventana,text="COAHUILA",command=coahuila).place(x=180,y=100)
b3=Button(ventana,text="DURANGO",command=durango).place(x=180,y=150)
b4=Button(ventana,text="GUERRERO",command=guerrero).place(x=180,y=200)
b5=Button(ventana,text="JALISCO",command=jalisco).place(x=180,y=250)
b6=Button(ventana,text="AÑADIR UN ESTADO",command=agg).place(x=158,y=300)

ventana.mainloop()

